# -*- coding: utf-8 -*-
"""ARAB Medical Center - report generator. Keeps original DOCX templates intact except header values."""
from pathlib import Path
import io, re, subprocess, tempfile, base64
import streamlit as st
import fitz
from docx import Document

APP_DIR = Path(__file__).resolve().parent
TEMPLATES_DIR = APP_DIR / "templates"
FIELDS = ("reg_no", "name", "pp_no", "date", "dob")
FIELD_LABELS = {
    "reg_no": "REG No", "name": "Name", "pp_no": "Passport No",
    "date": "Date / Date of Issue", "dob": "Date of Birth"
}

st.set_page_config(page_title="ARAB Medical Center | Report Generator", page_icon="📄", layout="centered")
st.title("ARAB Medical Center")
st.subheader("Medical Report Generator")
st.caption("শুধু রিপোর্টের উপরের বক্সের নির্ধারিত তথ্য পরিবর্তন হবে। মূল রিপোর্টের অন্য লেখা, টেবিল ও ফলাফল অপরিবর্তিত রাখার জন্য মূল Word template ব্যবহার করা হয়।")


def available_countries():
    TEMPLATES_DIR.mkdir(exist_ok=True)
    return sorted([p.stem for p in TEMPLATES_DIR.glob("*.docx") if not p.name.startswith("~$")], key=str.casefold)


def extract_fields(pdf_bytes):
    """Extract likely fields from text-based PDF. Always allow manual correction."""
    with fitz.open(stream=pdf_bytes, filetype="pdf") as pdf:
        text = "\n".join(page.get_text("text") for page in pdf)
    text = re.sub(r"[ \t]+", " ", text)
    result = {k: "" for k in FIELDS}
    pats = {
        "reg_no": [r"\bREG(?:ISTRATION)?\s*NO\.?\s*[:\-]?\s*([A-Z0-9-]+)"],
        "date": [r"\bDATE\s+OF\s+ISSUE\s*[:\-]?\s*(\d{1,2}[-/]\d{1,2}[-/]\d{4})", r"\bREG\.?\s*DATE\s*[:\-]?\s*(\d{1,2}[-/]\d{1,2}[-/]\d{4})", r"(?<!OF )\bDATE\s*[:\-]?\s*(\d{1,2}[-/]\d{1,2}[-/]\d{4})"],
        "name": [r"\bNAME\s*[:\n]+\s*([A-Z][A-Z .'-]{1,})"],
        "pp_no": [r"\bPASSPORT(?:\s*NO\.?)?\s*[:\-]?\s*([A-Z0-9-]{6,})", r"\bP\.?\s*P\.?\s*NO\.?\s*[:\-]?\s*([A-Z0-9-]{6,})"],
        "dob": [r"\bDATE\s+OF\s+BIRTH\s*[:\-]?\s*(\d{1,2}[-/]\d{1,2}[-/]\d{4})", r"\bBIRTH\s*DATE\s*[:\-]?\s*(\d{1,2}[-/]\d{1,2}[-/]\d{4})"]
    }
    for key, variants in pats.items():
        for pat in variants:
            m = re.search(pat, text, re.I)
            if m:
                value = re.sub(r"\s+", " ", m.group(1)).strip(" \t\r\n:")
                if key == "name":
                    value = re.split(r"\b(?:PROFESSION|PASSPORT|COUNTRY|BIRTH DATE|DATE OF BIRTH|REG\.?\s*DATE|EXP\.?\s*DATE)\b", value, flags=re.I)[0].strip()
                result[key] = value.replace("/", "-") if key in ("date", "dob") else value
                break
    return result


def iter_tables(container):
    for table in getattr(container, "tables", []):
        yield table
        for row in table.rows:
            for cell in row.cells:
                yield from iter_tables(cell)


def replace_value_in_paragraph(paragraph, start, end, new_value):
    """Replace character range across runs without rebuilding paragraph/cell."""
    runs = paragraph.runs
    run_texts = [r.text for r in runs]
    spans, cursor = [], 0
    for i, txt in enumerate(run_texts):
        spans.append((cursor, cursor + len(txt), i)); cursor += len(txt)
    affected = [(a,b,i) for a,b,i in spans if b > start and a < end]
    if not affected:
        return
    first, last = affected[0][2], affected[-1][2]
    first_offset = start - spans[first][0]
    last_offset = end - spans[last][0]
    if first == last:
        runs[first].text = run_texts[first][:first_offset] + new_value + run_texts[first][last_offset:]
    else:
        runs[first].text = run_texts[first][:first_offset] + new_value
        for _,_,idx in affected[1:-1]: runs[idx].text = ""
        runs[last].text = run_texts[last][last_offset:]


def replace_label_value_in_paragraph(paragraph, label_regex, value):
    if not value: return
    text = "".join(r.text for r in paragraph.runs)
    m = re.search(label_regex, text, re.I)
    if not m: return
    # Value starts after label and colon; preserve all label/spacing/colon characters.
    colon = text.find(":", m.start(), min(len(text), m.end()+5))
    if colon >= 0:
        start = colon + 1
        while start < len(text) and text[start].isspace(): start += 1
        end = start
        while end < len(text) and not text[end].isspace(): end += 1
        replace_value_in_paragraph(paragraph, start, end, value)


def replace_singapore_headers(doc, values):
    # Header boxes in the Singapore template contain the labels and values in a single cell.
    patterns = [
        (r"REG\s*NO\.?\s*:\s*", "reg_no", r"(?i)(REG\s*NO\.?\s*:\s*)([A-Z0-9-]+)"),
        (r"DATE\s*:\s*", "date", r"(?i)((?<!OF )\bDATE\s*:\s*)(\d{1,2}[-/]\d{1,2}[-/]\d{4})"),
        (r"NAME\s*:\s*", "name", r"(?i)(NAME\s*:\s*)(.*?)(?=\s+(?:P\.?\s*P\.?\s*NO|PASSPORT|DATE\s+OF\s+BIRTH|SEX)\s*:|$)"),
        (r"P\.?\s*P\.?\s*NO\.?\s*:\s*", "pp_no", r"(?i)(P\.?\s*P\.?\s*NO\.?\s*:\s*)([A-Z0-9-]+)"),
        (r"DATE\s+OF\s+BIRTH\s*:\s*", "dob", r"(?i)(DATE\s+OF\s+BIRTH\s*:\s*)(\d{1,2}[-/]\d{1,2}[-/]\d{4})"),
    ]
    for table in iter_tables(doc):
        table_text = " ".join(c.text for row in table.rows for c in row.cells).upper()
        if "REG" not in table_text or "NAME" not in table_text or "DATE" not in table_text:
            continue
        for row in table.rows:
            for cell in row.cells:
                for p in cell.paragraphs:
                    original = "".join(r.text for r in p.runs)
                    ops=[]
                    for _, key, pat in patterns:
                        val=(values.get(key) or "").strip()
                        if val:
                            for m in re.finditer(pat, original): ops.append((m.start(2),m.end(2),val))
                    for start,end,val in sorted(ops, reverse=True): replace_value_in_paragraph(p,start,end,val)


def replace_mauritius_header_table(doc, values):
    """Update only the patient-information header boxes across all Mauritius pages.

    The first-page header uses labels and values in separate table cells. Later
    pages use a compact single-cell line. Both structures are handled without
    rebuilding tables, paragraphs, or the rest of the report.
    """
    # First-page grid: each row contains a label cell and one or more value cells.
    for table in iter_tables(doc):
        if not table.rows:
            continue
        all_text = " ".join(cell.text.upper() for row in table.rows for cell in row.cells)
        is_first_grid = all(x in all_text for x in ("REG NO", "DATE OF ISSUE", "PASSPORT NO", "DATE OF BIRTH"))
        is_compact_header = all(x in all_text for x in ("REG NO", "DATE OF BIRTH")) and ("P.P NO" in all_text or "PASSPORT NO" in all_text) and "NAME" in all_text
        if not (is_first_grid or is_compact_header):
            continue

        # Grid-style labels in separate cells (first page).
        if is_first_grid:
            for row in table.rows:
                row_label = " ".join(cell.text.upper().strip() for cell in row.cells)
                key = None
                if "REG NO" in row_label: key = "reg_no"
                elif "DATE OF ISSUE" in row_label: key = "date"
                elif "PASSPORT NO" in row_label or "P.P NO" in row_label: key = "pp_no"
                elif "DATE OF BIRTH" in row_label: key = "dob"
                elif re.search(r"\bNAME\b", row_label): key = "name"
                if not key or not (values.get(key) or "").strip():
                    continue
                value = values[key].strip()
                for cell in row.cells:
                    for p in cell.paragraphs:
                        txt = "".join(r.text for r in p.runs)
                        m = re.search(r":\s*(.*?)\s*$", txt, re.S)
                        if m and m.group(1).strip():
                            replace_value_in_paragraph(p, m.start(1), m.end(1), value)

        # Compact header boxes on subsequent pages. Only process paragraphs that
        # actually contain the header labels; unrelated body paragraphs are skipped.
        if is_compact_header:
            patterns = [
                ("reg_no", r"(?i)(\bREG\s*NO\.?\s*:\s*)([A-Z0-9-]+)"),
                ("date", r"(?i)((?<!OF )\bDATE\s*:\s*)(\d{1,2}[-/]\d{1,2}[-/]\d{4})"),
                ("name", r"(?i)(\bNAME\s*:\s*)(.*?)(?=\s+DATE\s+OF\s+BIRTH\s*:|$)"),
                ("dob", r"(?i)(\bDATE\s+OF\s+BIRTH\s*:\s*)(\d{1,2}[-/]\d{1,2}[-/]\d{4})"),
                ("pp_no", r"(?i)(?:P\.?\s*P\.?\s*NO\.?|PASSPORT\s*NO\.?)\s*:\s*([A-Z0-9-]+)"),
            ]
            for row in table.rows:
                for cell in row.cells:
                    for p in cell.paragraphs:
                        original = "".join(r.text for r in p.runs)
                        if not re.search(r"(?i)REG\s*NO.*\bNAME\b", original):
                            continue
                        ops = []
                        for key, pattern in patterns:
                            value = (values.get(key) or "").strip()
                            if not value:
                                continue
                            for match in re.finditer(pattern, original):
                                # The passport pattern has only one capture group;
                                # other patterns capture the replacement as group 2.
                                group = 1 if key == "pp_no" else 2
                                ops.append((match.start(group), match.end(group), value))
                        for a, b, value in sorted(ops, reverse=True):
                            replace_value_in_paragraph(p, a, b, value)


def replace_header_fields(template_bytes, values, country):
    doc = Document(io.BytesIO(template_bytes))
    if country.casefold() == "mauritius":
        replace_mauritius_header_table(doc, values)
    else:
        replace_singapore_headers(doc, values)
    out=io.BytesIO(); doc.save(out); return out.getvalue()


def convert_docx_to_pdf(docx_bytes):
    with tempfile.TemporaryDirectory(prefix="arab_report_") as temp:
        temp=Path(temp); source=temp/"report.docx"; target=temp/"report.pdf"; source.write_bytes(docx_bytes)
        errors=[]
        for binary, profile in (("libreoffice","profile1"),("soffice","profile2")):
            try:
                p=subprocess.run([binary,"-env:UserInstallation=file://"+str(temp/profile),"--headless","--convert-to","pdf","--outdir",str(temp),str(source)],capture_output=True,text=True,timeout=90)
                if p.returncode==0 and target.exists(): return target.read_bytes()
                errors.append((p.stderr or p.stdout or f"exit {p.returncode}").strip())
            except Exception as e: errors.append(str(e))
        raise RuntimeError("PDF তৈরি হয়নি। Hosting settings-এ packages.txt অনুযায়ী LibreOffice ইনস্টল আছে কি না দেখুন। " + " | ".join(errors))

countries=available_countries()
if not countries:
    st.error("templates ফোল্ডারে .docx ফাইল নেই। Singapore.docx ও Mauritius.docx যোগ করুন।"); st.stop()

country=st.selectbox("১. দেশের ফরম্যাট নির্বাচন করুন", countries)
mode=st.radio("২. তথ্য দেওয়ার পদ্ধতি", ["Option A — Source PDF আপলোড", "Option B — হাতে তথ্য লিখব"], index=0)
if country.casefold()=="mauritius":
    st.info("Mauritius: মূল ৬ পৃষ্ঠার টেমপ্লেট ব্যবহার হবে। শুধু উপরের header box-এর তথ্য বদলানোর জন্য তৈরি।")

if "arab_values" not in st.session_state: st.session_state["arab_values"]={k:"" for k in FIELDS}
if "arab_preview_pdf" not in st.session_state: st.session_state["arab_preview_pdf"]=None

if mode.startswith("Option A"):
    st.markdown("#### Option A — PDF আপলোড করুন")
    with st.form("pdf_upload_form", clear_on_submit=False):
        uploaded=st.file_uploader("Source Report PDF নির্বাচন করুন", type=["pdf"], key="source_pdf")
        read_clicked=st.form_submit_button("Submit PDF — তথ্য পড়ুন", type="primary", use_container_width=True)
    if read_clicked:
        if uploaded is None:
            st.error("আগে PDF ফাইল নির্বাচন করুন, তারপর Submit PDF চাপুন।")
        else:
            try:
                got=extract_fields(uploaded.getvalue())
                st.session_state["arab_values"]={k:got.get(k,"") for k in FIELDS}
                st.session_state["arab_pdf_loaded"]=True
                st.success("PDF পড়া হয়েছে। নিচে তথ্য যাচাই/সংশোধন করে Preview Report চাপুন।")
                if not any(got.values()): st.warning("PDF থেকে লেখা পাওয়া যায়নি—এটি স্ক্যান করা PDF হতে পারে। তথ্য হাতে লিখুন।")
            except Exception as e: st.error(f"PDF পড়তে সমস্যা হয়েছে: {e}")
else:
    st.markdown("#### Option B — হাতে তথ্য লিখুন")
    st.caption("PDF লাগবে না। নিচে তথ্য লিখে Submit & Preview চাপুন।")

st.markdown("#### ৩. তথ্য যাচাই করুন")
with st.form("manual_fields_form", clear_on_submit=False):
    c1,c2=st.columns(2)
    new_values={}
    for i,key in enumerate(FIELDS):
        with (c1 if i%2==0 else c2):
            new_values[key]=st.text_input(FIELD_LABELS[key], value=st.session_state["arab_values"].get(key,""), key="input_"+key)
    submitted=st.form_submit_button("Submit & Preview Report", type="primary", use_container_width=True)

if submitted:
    missing=[FIELD_LABELS[k] for k in FIELDS if not new_values.get(k,"").strip()]
    if missing:
        st.error("এই তথ্যগুলো পূরণ করুন: " + ", ".join(missing))
    else:
        template_path=TEMPLATES_DIR/(country+".docx")
        if not template_path.exists(): st.error("এই দেশের Word template পাওয়া যায়নি: "+template_path.name)
        else:
            try:
                values={k:v.strip() for k,v in new_values.items()}
                changed=replace_header_fields(template_path.read_bytes(),values,country)
                pdf=convert_docx_to_pdf(changed)
                with fitz.open(stream=pdf,filetype="pdf") as check_pdf: page_count=len(check_pdf)
                if country.casefold()=="mauritius" and page_count!=6:
                    st.warning(f"সতর্কতা: Mauritius PDF-এ {page_count} পৃষ্ঠা পাওয়া গেছে; প্রত্যাশিত ৬ পৃষ্ঠা। ডাউনলোডের আগে মূল ফরম্যাট যাচাই করুন।")
                st.session_state["arab_preview_docx"]=changed
                st.session_state["arab_preview_pdf"]=pdf
                st.session_state["arab_preview_values"]=values
                st.session_state["arab_preview_country"]=country
                st.session_state["arab_page_count"]=page_count
                st.success(f"Preview তৈরি হয়েছে — মোট {page_count} পৃষ্ঠা।")
            except Exception as e: st.error(f"রিপোর্ট তৈরি করা যায়নি: {e}")

if st.session_state.get("arab_preview_pdf"):
    pdf=st.session_state["arab_preview_pdf"]; docx=st.session_state["arab_preview_docx"]
    values=st.session_state["arab_preview_values"]
    safe=lambda s: re.sub(r"[^A-Za-z0-9_-]+","_",s).strip("_") or "Report"
    filename=safe(values.get("reg_no","Report"))+"_"+safe(values.get("name","Patient"))
    st.markdown("### ৪. PDF Preview")
    st.caption(f"দেশ: {st.session_state['arab_preview_country']} · পৃষ্ঠা: {st.session_state.get('arab_page_count','—')}")
    b64=base64.b64encode(pdf).decode("ascii")
    st.components.v1.html(f'<iframe src="data:application/pdf;base64,{b64}" width="100%" height="720" style="border:1px solid #ddd;border-radius:8px"></iframe>',height=735,scrolling=True)
    st.warning("প্রতিটি পৃষ্ঠা দেখে নিশ্চিত করুন—শুধু header তথ্য বদলেছে এবং বাকি লেখা/বিন্যাস ঠিক আছে।")
    c1,c2=st.columns(2)
    with c1: st.download_button("Done — Word ডাউনলোড",data=docx,file_name=filename+".docx",mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",use_container_width=True)
    with c2: st.download_button("Done — PDF ডাউনলোড",data=pdf,file_name=filename+".pdf",mime="application/pdf",use_container_width=True)

with st.expander("Online deploy করার ফাইলগুলো"):
    st.write("app.py, requirements.txt, packages.txt এবং templates/ ফোল্ডারের Word ফাইল একসঙ্গে GitHub repository-তে আপলোড করুন। Streamlit Community Cloud-এ app.py-কে main file হিসেবে নির্বাচন করুন।")
