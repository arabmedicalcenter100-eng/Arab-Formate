# ARAB Medical Center — Medical Report Generator

এই অ্যাপটি Singapore ও Mauritius-এর দেওয়া Word টেমপ্লেট ব্যবহার করে রিপোর্ট তৈরি করে। মূল DOCX টেমপ্লেটের লেখা/টেবিল নতুন করে বানানো হয় না; নির্দিষ্ট header box-এর তথ্য পরিবর্তন করা হয়। Mauritius-এর মূল টেমপ্লেটটি Letter size এবং LibreOffice PDF conversion-এ ৬ পৃষ্ঠা হিসেবে যাচাই করা হয়েছে।

## অ্যাপের সুবিধা
- দেশ নির্বাচন: Singapore / Mauritius
- Option A: Source PDF আপলোড করে লেখা PDF থেকে সম্ভাব্য তথ্য পড়া; এরপর ফর্মে যাচাই/সংশোধন
- Option B: PDF ছাড়াই হাতে তথ্য লেখা
- Submit & Preview Report বাটন
- PDF Preview এবং Word/PDF ডাউনলোড
- Mauritius-এর মূল টেমপ্লেটের ৬ পৃষ্ঠা বজায় আছে কি না, তা PDF তৈরি হওয়ার পরে পৃষ্ঠা সংখ্যা দিয়ে যাচাই

## অনলাইনে চালানো (Streamlit Community Cloud)
1. ZIP ফাইল Extract করুন।
2. `arab_report_web_app` ফোল্ডারের ভেতরের সব ফাইল ও `templates` ফোল্ডার GitHub repository-তে আপলোড করুন।
3. https://share.streamlit.io/ খুলে repository নির্বাচন করুন।
4. Main file path হিসেবে `app.py` দিন এবং Deploy করুন।
5. `requirements.txt` ও `packages.txt` একই ফোল্ডারে থাকতে হবে; `templates/Singapore.docx` এবং `templates/Mauritius.docx` অবশ্যই থাকতে হবে।

## স্থানীয় কম্পিউটারে চালানো
Python 3.10 বা পরের সংস্করণ এবং LibreOffice ইনস্টল করুন। টার্মিনালে অ্যাপ ফোল্ডারে গিয়ে চালান:

```bash
pip install -r requirements.txt
streamlit run app.py
```

## গুরুত্বপূর্ণ
- Text-based PDF হলে স্বয়ংক্রিয়ভাবে তথ্য পড়ার চেষ্টা করবে। স্ক্যান করা/ছবির PDF হলে হাতে তথ্য লিখুন।
- PDF থেকে পড়া তথ্য অবশ্যই যাচাই করুন।
- Mauritius টেমপ্লেট PDF-এ ৬ পৃষ্ঠা না হলে অ্যাপ সতর্কবার্তা দেখায়।
- নতুন তথ্য বসানোর পর প্রতিটি পৃষ্ঠা Preview দেখে নিশ্চিত করুন যে header values ঠিক আছে এবং অন্য লেখা/বিন্যাস অক্ষত আছে। Word/LibreOffice সংস্করণভেদে visual spacing বদলাতে পারে।
- `Live_Preview.html` হলো কেবল standalone UI demonstration; আসল DOCX/PDF তৈরির জন্য Streamlit অ্যাপ (`app.py`) ব্যবহার করুন।
